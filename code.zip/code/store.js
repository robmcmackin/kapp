import { createStore } from "redux"


import koreanApp from "./reducers"

export default createStore(koreanApp)