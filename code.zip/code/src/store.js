import { createStore, applyMiddleware } from 'redux';
import koreanApp from "./reducers"
import { composeWithDevTools } from 'redux-devtools-extension';

const store = createStore(koreanApp, composeWithDevTools(
  //applyMiddleware(...middleware),
  // other store enhancers if any
));


export default store;

