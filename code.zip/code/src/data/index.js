import Levels from './levels.json';

export default {Levels};