import Levels from '../../src/data';
export function completeLevel(currentLevel) {
  return {
    type: "COMPLETE_LEVEL",
    payload: currentLevel
  }
}
export function selectSyllable() {
  return {
    type: 'SELECT_SYLLABLE'
  }
}
export function completeWord() {
  return {
    type: 'COMPLETE_WORD'
  }
}
export function updateLevel(level) {
  return{
    type: 'SET_LEVEL',
    padload: level
  }
}
export function setLevel(level) {
  console.log("setlevel ar", level)
  const keySyllable = Levels.Levels[level].korean;
  const syllables = Levels.Levels[level].words[0].korword.split("");
  //create new word object also 
  const levels = Levels.Levels;
  //put all korean syllables into array
  const ksyllables = levels.map((level) => {
  return {korean : level.korean, english : level.english};
  });
  //filter out passed arguments
  const filtered = ksyllables.filter(function(val){
  return syllables.indexOf(val.korean) === -1;
  });
  //generate array of random sylabbles
  const randomHanjas = new Array(syllables.length).fill(undefined).map((val) => {
  return filtered[Math.floor(Math.random() * filtered.length)];
  });
  const randomPositions = new Array(syllables.length).fill(undefined).map((val) => {
    return 0.5 - Math.random();  
  });

  return {
    type: 'SET_LEVEL',
    payload:syllables,
            randomHanjas,
            randomPositions,
            keySyllable,
            level
  }
}
export function setWord(num) {
  
  return {
    type: 'SET_WORD',
    payload: num
  }
} 
export function createWordObject(syllables, keySyllable) {  
    const levels = Levels.Levels;
    //put all korean syllables into array
    const ksyllables = levels.map((level) => {
      return {korean : level.korean, english : level.english};
    });
    //filter out passed arguments
    const filtered = ksyllables.filter(function(val){
      return syllables.indexOf(val.korean) === -1;
    });
    //generate array of random sylabbles
    const randomHanjas = new Array(syllables.length).fill(undefined).map((val) => {
      return filtered[Math.floor(Math.random() * filtered.length)];
    });
    const randomPositions = new Array(syllables.length).fill(undefined).map((val) => {
        return 0.5 - Math.random();  
    });
    
    return {
      type: 'SET_SYLLABLES',
      payload: syllables,
        randomHanjas,
        randomPositions,
        keySyllable
    }
}
export function completeTile(id, correct) {
    return{

      type: 'COMPLETE_TILE',
      payload: id, correct
    }
}