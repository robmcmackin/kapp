import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import Levels from '../../src/data';
import GameManager from './GameManager';
import { Provider } from "react-redux"
import store from "../store"

if (typeof window !== 'undefined') {
    window.React = React;
}

store.subscribe(() => {
	console.log("store changed", store.getState())
})

ReactDOM.render(
	<Provider store={store}>
	<GameManager levels={Levels} />
	</Provider>,
	document.getElementById('gameview')
)

