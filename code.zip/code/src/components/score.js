import React, {Component} from 'react';

class Score extends Component{
	constructor(props) {
    	super(props);
	}
	render(){
		return(
			<div className="score-header">
				<div className="score-wrap">
					<div className="score-holder">
						<div className="score-title">
							Hanja 
						</div>
						<div className="score">
							10
						</div>
						<div className="score-total">
							/50
						</div>
					</div>
					<div className="score-holder">
						<div className="score-title">
							Word 
						</div>
						<div className="score">
							25
						</div>
						<div className="score-total">
							/250
						</div>
					</div>
					<div className="clear" />
				</div>
			</div>
		)
	}
}
export default Score;