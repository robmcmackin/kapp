import React, { Component } from 'react';

class IncorrectGameTile extends Component {
	render(){
		const isHidden = this.props.show ? ' ' : ' hide';
		const isComplete = this.props.completed ? "correct" : "";
		const className = "game-tile " + isComplete;
		return(
			<div className={className}>{ this.props.character }</div>
			)
	}
}
export default GameTile;