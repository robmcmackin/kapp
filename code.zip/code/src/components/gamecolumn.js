import React, {Component} from 'react';
import GameTile from './gametile'
import ReactCSSTransitionReplace from 'react-css-transition-replace-next';
class GameColumn extends Component {
  	render(){
  		let tiles = null;
  		if(this.props.keySyllable){
  			tiles = [

	  				<GameTile 
	  					completed={true} 
	  					correct={true} 
	  					character={ this.props.syllable.character }
	  					key={this.props.currentWord + " " + this.props.id} />]
	  	}else if(this.props.syllable.character != undefined){
	  		//const showIncorrect = !this.state.complete;
  			//generate shuffled array of hanja and correct hanja with randomized position

	  		const options = [

	            <GameTile 
	  							completed={ this.props.syllable.completed }
	  							key={this.props.currentWord + " " + this.props.id + " 1"}
	  							correct={ false }
	  							character={ this.props.randomHanja.character }
	  							selected={ this.props.randomHanja.selected }
	  							id={ this.props.id }
	  							keyid={ this.props.currentWord + " " + this.props.id + " 1" }
	  							clickTile={ this.props.clickTile } />,

							<GameTile 
								completed={ this.props.syllable.completed }
								key={this.props.currentWord + " " + this.props.id + " 2"}
								correct={ true }  
								character={ this.props.syllable.character }
								id={ this.props.id }
								keyid={ this.props.currentWord + " " + this.props.id + " 2" }
								clickTile={ this.props.clickTile } />]

			const syllablePositions = this.props.syllable.position
	  		const shuffledOptions = options.sort(function(a, b){return syllablePositions});
	  		tiles = shuffledOptions;
	  		
	  	} 
	  	let tile1 = null;
	  	if(tiles!=undefined){
	  		tile1 = tiles[0]
	  	}
	  	return(
	  		<div className="game-tile-column">
	  		
	  			        
	            {tiles}

				
			
			</div>
  		)

  	}
}
export default GameColumn;