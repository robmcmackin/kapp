import React, {Component} from 'react';

class CurrentLevel extends Component {
	render(){
		return(
			<span className="current-level">
				 {this.props.levelName.korean} {this.props.levelName.english}
			</span>
		)
	}
}
export default CurrentLevel;