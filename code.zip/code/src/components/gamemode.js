import React, {Component} from 'react';
import Levels from '../../src/data';
import CurrentLevel from './currentlevel';
import ProgressBar from './progressbar';
import GameGrid from './gamegrid';
import { connect } from "react-redux"


class GameMode extends Component{
	render(){
		const { currentLevel, currentWord } = this.props

		const progress = (currentWord / Levels.Levels[currentLevel].words.length ) * 100
		const style = {
      		width: `${progress}%`,
    	};

		return(
			<div>
				<div className="game-header">
					<div className="back-button"></div>
					<CurrentLevel levelName={{english : Levels.Levels[currentLevel].english, korean : Levels.Levels[currentLevel].korean}} />
					<ProgressBar progressStyle={style} />
				</div>
				<div className="game-body">
					<span className="level-instruction">Choose the Korean for </span>
					<span className="level-word">{ Levels.Levels[currentLevel].words[currentWord].engword}</span>
					<GameGrid />

				</div>
			</div>
		)
	}
}



const mapStateToProps = (state) => {
  return {
    currentWord: state.current_word,
    currentLevel: state.current_level,

  };
};



export default connect(mapStateToProps)(GameMode);