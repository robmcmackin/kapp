import React, {Component} from 'react';

class ProgressBar extends Component {
	render(){
		return(
			<div className="progress-holder">
				<div key="1" style={this.props.progressStyle} className="progress-indicator"></div>
			</div>
		)
	}
}

export default ProgressBar;