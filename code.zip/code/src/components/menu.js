import React, {Component} from 'react';
import Score from './Score';
import LevelsGrid from './LevelsGrid';
import { connect } from "react-redux";
import { setLevel } from "../actions"

class Menu extends Component {
	render() {
	    return (
			<div>
				<Score />
				<div className="clear" />
				<LevelsGrid unlockedLevel={this.props.unlockedLevel} setLevel={this.props.setLevel} levels={this.props.levels} />
			</div>
		);
	}
}
const mapStateToProps = (state) => {
  return {
	
  };
};

const mapDispatchToProps = (dispatch) => {
    return {
        setLevel: (level) => {
        	dispatch(setLevel(level));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Menu);