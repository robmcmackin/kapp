import React, {Component} from 'react';

class LevelsGrid extends Component {
	render() {
		const levelsList = this.props.levels.slice(0, this.props.unlockedLevel + 1).map((value, key) => {
			return(
				<div key={key} className={"level-tile " + (this.props.unlockedLevel === key ? "latest" : "")}  onClick={() => this.props.setLevel(key)}>
					<div className="korean">{value.korean}</div>
					<div className="english">{value.english}</div>
					<div className="tile-info-bar">
						<span className="hanja">{value.hanja}</span>
						<span className="word-count">5/5</span>
					</div>
				</div>
			)
		})
	    return (
			<div className="levels-grid">
				{levelsList}
			</div>
		);
	}
}
export default LevelsGrid;