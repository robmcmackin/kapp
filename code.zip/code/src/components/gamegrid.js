import React, {Component} from 'react';
import GameColumn from './gamecolumn'
import { connect } from "react-redux"
import Levels from '../../src/data';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import { completeTile } from "../actions"
import { completeLevel } from "../actions"
import { createWordObject } from "../actions"
import { setWord } from "../actions"



class GameGrid extends Component {

  clickTile = (id, correct) =>{
      //check word completed or level completed 
      let countComplete = 0;
      for(let i=0; i<this.props.currentSyllables.length;i++){
        if(this.props.currentSyllables[i].completed===true){
          countComplete+=1;
        }
      }
      let wordComplete = this.props.currentSyllables.length -1 === countComplete && correct
      let levelComplete = this.props.currentWord === Levels.Levels[this.props.currentLevel].words.length -1;

      if(wordComplete){
        if(!levelComplete){
          //word complete

          const keySyllable = Levels.Levels[this.props.currentLevel].korean;
          const syllables = Levels.Levels[this.props.currentLevel].words[this.props.currentWord + 1].korword.split("");

          this.props.createWordObject(syllables, keySyllable);
          this.props.setWord(this.props.currentWord + 1);

        }else{
          //level complete

          this.props.completeLevel(this.props.currentLevel);
        }
      } else{
        //just tile complete

        this.props.completeTile(id, correct)
      } 
  }
	render(){
		//TODO: potentially pass in syllables as props
    const emptyGrid = [{},{},{},{},{}]
		const syllables = this.props.currentSyllables


    const syllableFilledGrid = emptyGrid.map((val, key) => {
      if(syllables[key]!=undefined){
        return syllables[key];
      }else{
        return {}
      }
    })
		//load tiles with syllables
		const sylCount = 0;
    const keySyllable = Levels.Levels[this.props.currentLevel].korean;
    
		const gameGrid = syllableFilledGrid.map((syllable, key) => {
        let isKeySyllable = false;
        if(syllables.character!=undefined){
          isKeySyllable = syllable.character === keySyllable ? true : false 
        }
				return (
    
					<GameColumn 
          clickTile={ this.clickTile } 
          key={"col " + key}
          id={key} 
          currentWord={this.props.currentWord}
          syllable={syllable} 
          keySyllable={ isKeySyllable }
          randomHanja={ this.props.randomHanjas[key] } />

					)
		})
		return(
			<div className="game-grid-container">
          {gameGrid}

      </div>
		)
	}
}



const mapStateToProps = (state) => {
  return {
    currentWord: state.current_word,
    currentLevel: state.current_level,
    currentSyllables: state.current_syllables,
    randomHanjas: state.random_hanjas	
  };
};

const mapDispatchToProps = (dispatch) => {
    return {
        completeTile: (id, correct) => {
            dispatch(completeTile(id, correct));
        },
        createWordObject: (syllables, keySyllable) =>{
            dispatch(createWordObject(syllables, keySyllable))
        },
        setWord: (word) =>{
            dispatch(setWord(word))
        },
        completeLevel: (currentLevel) =>{
            dispatch(completeLevel(currentLevel))
        }

    };
};

export default connect(mapStateToProps, mapDispatchToProps)(GameGrid);