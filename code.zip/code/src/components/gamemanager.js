import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import Menu from './Menu';
import GameMode from './Gamemode';
import { connect } from "react-redux";
import Levels from '../../src/data';
import { createWordObject } from "../actions"
import { setWord } from "../actions"
import { setGameScene } from "../actions"

class GameManager extends Component {
	constructor(props) {
		super(props);
		this.getWordPos = this.getWordPos.bind(this);
		this.updateWordPos = this.updateWordPos.bind(this);
	}
	getWordPos() {
		return this.state.currentWord;
	}
	updateWordPos(pos) {
		this.setState({
			currentWord: pos
		})
	}
	componentWillMount() {
			//set up initial syllables
			const keySyllable = Levels.Levels[this.props.currentLevel].korean;
			const syllables = Levels.Levels[this.props.currentLevel].words[this.props.currentWord].korword.split("");
			this.props.createWordObject(syllables, keySyllable);	
			//check for new level or word

	}
	
	render() {

		const levels = this.props.levels.Levels;
		const sceneInstance = (() => {
	      switch (this.props.currentScene) {
	        case 'Intro': return <Intro />;
	        case 'Menu': return <Menu unlockedLevel={this.props.unlockedLevel} levels={levels} />;
	        case 'GameMode': return <GameMode />;
	        case 'LevelComplete': return <LevelComplete />;
	        default: return null;
	      }
	    })();
	    return (
	    	<div className="scene-director">
        	{sceneInstance}
      		</div>
		);
	}
	
};

const mapStateToProps = (state) => {
  return {
    currentWord: state.current_word,
    currentLevel: state.current_level,
    currentScene: state.current_scene,	
    unlockedLevel: state.unlocked_level,	
  };
};

const mapDispatchToProps = (dispatch) => {
    return {
        createWordObject: (syllables, keySyllable) => {
            dispatch(createWordObject(syllables, keySyllable));
        },
        setWord: (num) => {
        	dispatch(setWord(num));
        },
        setGameScene: (scene) => {
        	dispatch(setGameScene(scene));
        }

    };
};

export default connect(mapStateToProps, mapDispatchToProps)(GameManager);