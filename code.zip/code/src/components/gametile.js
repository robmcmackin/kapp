import React, { Component } from 'react';
import ReactCSSTransitionReplace from 'react-css-transition-replace';
class GameTile extends Component {
	componentWillUnmount = () => {

	}
	render(){
		//check classes to apply
		const isComplete = this.props.completed ? " complete" : ""
		const isHidden = this.props.completed && !this.props.correct ? ' hide' : ' ';
		const isIncorrectSelected = !this.props.correct && this.props.selected ? " incorrect" : ""
		
		const className = "game-tile" + isComplete + isIncorrectSelected + isHidden ;
		
		return(
  
			<div key={this.props.keyid} className={className} onClick={() => !this.props.completed ? this.props.clickTile(this.props.id, this.props.correct) : ""} >{ this.props.character }</div>

			)
	}
}


export default GameTile;