
import { combineReducers } from 'redux';

import current_syllables from "./syllables"
import random_hanjas from "./randomhanja"
import { current_word, current_level, current_scene, unlocked_level } from "./gamestate"


const koreanApp = combineReducers({
  current_level, 
  unlocked_level,
  current_scene,
  current_syllables,
  current_word, 
  random_hanjas
});

export default koreanApp;
