export const current_level = (state = 5, action) => {
  switch (action.type) {
    case 'COMPLETE_LEVEL':{
      const nextLevel = state + 1
      return nextLevel;
    }
    case 'UPDATE_LEVEL': {
      return action.payload;
    }
    case 'SET_LEVEL':{
      return action.level;
    }
    default:{
      return state
    }
  } 
}
export const unlocked_level = (state = 5, action) => {
  switch (action.type) {
    case 'COMPLETE_LEVEL':{
      let nextLevel = state
      if(action.payload===state){
        nextLevel = state + 1
      }
      console.log("updatin unlocked level to ", nextLevel, " from ", state)
      return nextLevel;
    }
    default:{
      return state
    }
  } 
}
export const current_word = (state = 0, action) => {
  switch (action.type) {
    case 'SET_WORD':{
      return action.payload;
    }
    case 'SET_LEVEL':{
      return 0;
    }
    default: {
      return state;
    }
  }
}

export const current_scene = (state = "Menu", action) => {
  switch (action.type) {
    case 'COMPLETE_LEVEL':{
      return "Menu";
    }
    case 'SET_LEVEL':{
      return "GameMode";
    }
    default: {
      return state;
    }
  }
}