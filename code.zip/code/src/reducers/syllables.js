import Levels from '../../src/data';

const current_syllables = (state = [], action) => {
   switch (action.type) {
    case "SET_SYLLABLES": 
    {
      const levels = Levels.Levels
      const syllables = action.payload.map((syllable, key) => {
        return {
          character: syllable,
          position: action.randomPositions[key],
          completed: syllable === action.keySyllable ? true : false
        }
      });
      return Object.assign([], syllables);
    }
    case "SET_LEVEL": 
    {
      const levels = Levels.Levels
      const syllables = action.payload.map((syllable, key) => {
        return {
          character: syllable,
          position: action.randomPositions[key],
          completed: syllable === action.keySyllable ? true : false
        }
      });
      return Object.assign([], syllables);
    }
    case "COMPLETE_TILE": {
      if(action.correct){
        return Object.assign([], state,  
                          state.slice(0, action.payload)
                          .concat(Object.assign(state[action.payload], { completed: true }))
                          .concat(state.slice(action.payload + 1))
                         );
        }
      }
    default: {
      return state;
    }
    }
    
}

export default current_syllables;