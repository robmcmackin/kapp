const random_hanjas = (state = {}, action) => {
   switch (action.type) {
    case "SET_SYLLABLES": 
    {
      const randomhanj = action.payload.map((val, key) => {
        return{
            character: action.randomHanjas[key].korean,
            english: action.randomHanjas[key].english,
            selected: false
          }
      });
      //console.log("state is", random_hanjas)
      return Object.assign([], state, randomhanj)
    }
    case "COMPLETE_TILE": {

      if(!action.correct){
        console.log("AC", action.correct)
        return Object.assign([], state, {
                        random_hanjas: 
                          state.slice(0, action.payload)
                          .concat(Object.assign(state[action.payload], { selected: true }))
                          .concat(state.slice(action.payload + 1))
                         });
        }
      }
    default: 
    {
      return state;
    }
  }
}
export default random_hanjas;
